//
//  TasksTableViewController.swift
//  SimpleCoreDataList-Swift
//
//  Created by Bronson Dupaix on 3/22/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import UIKit
import CoreData

class TasksTableViewController: UITableViewController {
    
    var tasksArray = [NSManagedObject]()
    
    var nameString: String = ""
    
    var moc = DataController().managedObjectContext
    
    let today = NSDate()
    
    let dateFormatter = NSDateFormatter()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.fetchTasks()

    }
    
    //Mark: - Add Task Button

    @IBAction func addTaskButton(sender: AnyObject) {
        
        print("AddTaskTapped")
        //Step-1 create a UIAlertController
        let alertController = UIAlertController(title: "Add", message: "Please add a task name", preferredStyle: .Alert)
        
        //Step-2 create action for alert controller/ Save and Cancel
        
        let saveAction = UIAlertAction(title: "Save", style: .Default) { (alertAction) -> Void in
            
            print("SavePressed")
            
              // Step-5 add textfield
            
            if let textField = alertController.textFields?.first,
                let name = textField.text {
                    
                    
                    self.dateFormatter.dateFormat = "MM-dd-yy HH:mm"
                    
                    let todayString = self.dateFormatter.stringFromDate(self.today)

                    self.saveTask(name, created: todayString)
                    
                    print(todayString) 
                    
                    self.tableView.reloadData()
                    
                   //  print("Name:\(self.nameString)")
            }
            
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .Default) { (alertAction) -> Void in
            
            print("CancelledPressed")
        }
        
      
 
        
        //Step-6 add text field to alert controller
        
        
        alertController.addTextFieldWithConfigurationHandler { (textField) -> Void in
         
        }
        
        
        //Step-3 add actions to alert controller
        alertController.addAction(saveAction)
        
        alertController.addAction(cancelAction)
        
        //Step-4 present the action view controller over the top of the current view controller
        
        self.presentViewController(alertController, animated: true, completion:nil)
        
        
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
  
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
 
        return self.tasksArray.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("TaskCell", forIndexPath: indexPath)
        
        
        let task = self.tasksArray[indexPath.row]
        
        if let name = task.valueForKey("name") as? String {
 
        cell.textLabel?.text = name
            
        }

        return cell
    }


    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */
    
    //Mark: - Utility Methods 
    
    func showAlert(title: String, message: String){
        
        print("AddTaskTapped")
        //Step-1 create a UIAlertController
        let alertController = UIAlertController(title: title, message: message,preferredStyle: .Alert)
        
        //Step-2 create action for alert controller/ Save and Cancel
        
        let okAction = UIAlertAction(title: "OK", style: .Default) { (alertAction) -> Void in
            
            print("OKPressed")
            
        }
        
        //Step-3 add actions to alert controller
        
        alertController.addAction(okAction)

        
        self.presentViewController(alertController, animated: true, completion: nil)
        
    }
    
    
    func saveTask(name: String, created: String) {
        
        // Step-1 Create Entity with type desired
        
        if let taskEntity = NSEntityDescription.entityForName("Task", inManagedObjectContext: self.moc) {
        
        // Step -2 create an NSManaged object out of our entity
            
            // Step - 3 create a var from our DataController / moc
        let task = NSManagedObject(entity: taskEntity, insertIntoManagedObjectContext: self.moc)
            
            task.setValue(name, forKey:"name")
            
            // Step-4  save our object
            

            
            do {
                
                try self.moc.save()
                
                print("Saved Task")
                
                // Step-5 append task to array
                
                self.tasksArray.append(task)
            
                
            } catch {
                
                print(" Error couldnt save task")
            }
        
        }
        
        
    }
    
    func fetchTasks() {
        
        //Step-1  Create fetch request
        
        let fetchRequest = NSFetchRequest(entityName: "Task")
        
        //Step-2 decide how to sort fetched objects
        
        let sortDescriptor = NSSortDescriptor(key: "name" , ascending: true)
        
        
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        do {
            
            if let results = try self.moc.executeFetchRequest(fetchRequest) as? [NSManagedObject] {
                
                self.tasksArray = results
                
                self.tableView.reloadData()
                
                print("Tasks have been fetched")
                
            }
            
        }catch {
            
            print("Error couldnt fetch items")
        }
        
    }
}
